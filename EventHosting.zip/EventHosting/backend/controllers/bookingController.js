const Booking = require("../models/bookingModel");
const Product = require("../models/eventModel");
const ErrorHander = require("../utils/errorhander");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

// Create new Booking-admin/organizer
exports.newBooking = catchAsyncErrors(async (req, res, next) => {
  const {
    bookingTickets,
    paymentInfo,
    paidAt,
    totalPrice,
    bookingStatus,
    createdAt 
  } = req.body;

  const booking = await Booking.create({
    bookingTickets,
    paymentInfo,
    paidAt,
    totalPrice,
    bookingStatus,
    createdAt, 
    paidAt: Date.now(),
    user: req.user._id,
  });

  res.status(201).json({
    success: true,
    booking,
  });
});

// get Single booking
exports.getSingleBooking = catchAsyncErrors(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id).populate(
    "user",
    "name email"
  );

  if (!booking) {
    return next(new ErrorHander("Booking not found with this Id", 404));
  }

  res.status(200).json({
    success: true,
    booking,
  });
});

// get logged in user  Bookings
exports.myBookings = catchAsyncErrors(async (req, res, next) => {
  const bookings = await Booking.find({ user: req.user._id });

  res.status(200).json({
    success: true,
    bookings,
  });
});

// get all Bookings -- Admin
exports.getAllBookings = catchAsyncErrors(async (req, res, next) => {
  const bookings = await Booking.find();

  let totalAmount = 0;

  bookings.forEach((booking) => {
    totalAmount += booking.totalPrice;
  });

  res.status(200).json({
    success: true,
    totalAmount,
    bookings,
  });
});

// update Booking Status -- Admin
exports.updateBooking = catchAsyncErrors(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorHander("Booking not found with this Id", 404));
  }

  if (booking.bookingStatus === "Confirmed") {
    return next(new ErrorHander("You have already confirmed this booking", 400));
  }

  if (req.body.status === "Not confirmed") {
    booking.bookingItems.forEach(async (o) => {
      await updateStock(o.event, o.seats);
    });
  }
  booking.bookingStatus = req.body.status;

  if (req.body.status === "Confirmed") {
    booking.deliveredAt = Date.now();
  }

  await booking.save({ validateBeforeSave: false });
  res.status(200).json({
    success: true,
  });
});

async function updateSeats(id, quantity) {
  const event = await Event.findById(id);

  event.Seats -= quantity;

  await event.save({ validateBeforeSave: false });
}

// delete Booking -- Admin/Organizer
exports.deleteBooking = catchAsyncErrors(async (req, res, next) => {
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    return next(new ErrorHander("Booking not found with this Id", 404));
  }

  await booking.remove();

  res.status(200).json({
    success: true,
  });
});
