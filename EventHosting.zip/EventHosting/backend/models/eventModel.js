const mongoose = require("mongoose");

const eventSchema = mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please Enter event Name"],
    
  },
  description: {
    type: String,
    required: [true, "Please Enter event Description"],
  },
  price: {
    type: Number,
    required: [true, "Please Enter event Price"],
    
  },
  location:{
    type:String,
    required:[true,"Please enter the location"],
  },
  eventDate:{
    type:Date,
    required:[true,"Please enter the event Date"],
  },
  ratings: {
    type: Number,
    default: 0,
  },
  images: [{
      url: {
        type: String,
        required: true,
      }  
    }],
  category: {
    type: String,
    required: [true, "Please Enter event Category"],
  },
  seats: {
    type: Number,
    required: [true, "Please enter maximum number of seats for event"],
    default: 1,
  },
  numOfReviews: {
    type: Number,
    default: 0,
  },
  reviews: [
    {
      user: {
        type: mongoose.Schema.ObjectId,
        ref: "User",
        required: true,
      },
      name: {
        type: String,
        required: true,
      },
      rating: {
        type: Number,
        required: true,
      },
      comment: {
        type: String,
        required: true,
      },
    },
  ],

  user: {
    type: mongoose.Schema.ObjectId,
    ref: "User",
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("event", eventSchema);
